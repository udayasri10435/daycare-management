/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Baby, 
  CreditCard, 
  HeartPulse, 
  Calendar, 
  ShieldCheck, 
  Settings, 
  Activity, 
  MessageSquare, 
  Bell,
  Search,
  Plus,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  LayoutDashboard,
  Menu,
  X,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { FirebaseProvider, useAuth } from './components/FirebaseProvider';
import { AuthGuard } from './components/AuthGuard';
import { ErrorBoundary } from './components/ErrorBoundary';
import { auth, db, setDoc, doc, collection, OperationType, handleFirestoreError } from './firebase';
import { useFirestoreCollection } from './hooks/useFirestore';

// --- Types ---

type Domain = 
  | 'dashboard' 
  | 'enrollment' 
  | 'staff' 
  | 'billing' 
  | 'scheduling' 
  | 'health' 
  | 'compliance' 
  | 'infrastructure' 
  | 'operations'
  | 'parent_portal';

interface Child {
  id: string;
  name: string;
  age: string;
  classroom: string;
  status: 'enrolled' | 'waitlist' | 'graduated';
  lastActivity: string;
}

interface Staff {
  id: string;
  name: string;
  role: string;
  status: 'active' | 'on-leave' | 'off-duty';
  classroom: string;
}

interface Microservice {
  id: string;
  name: string;
  domain: string;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
}

// --- Mock Data ---

const MOCK_CHILDREN: Child[] = [
  { id: '1', name: 'Liam Smith', age: '2y 4m', classroom: 'Toddlers A', status: 'enrolled', lastActivity: 'Napping' },
  { id: '2', name: 'Olivia Brown', age: '1y 2m', classroom: 'Infants B', status: 'enrolled', lastActivity: 'Lunch' },
  { id: '3', name: 'Noah Davis', age: '3y 1m', classroom: 'Preschool A', status: 'enrolled', lastActivity: 'Story Time' },
  { id: '4', name: 'Emma Wilson', age: '2y 8m', classroom: 'Toddlers B', status: 'waitlist', lastActivity: 'N/A' },
  { id: '5', name: 'Ava Garcia', age: '4y 0m', classroom: 'Pre-K', status: 'enrolled', lastActivity: 'Outdoor Play' },
];

const MOCK_STAFF: Staff[] = [
  { id: '1', name: 'Sarah Johnson', role: 'Lead Teacher', status: 'active', classroom: 'Toddlers A' },
  { id: '2', name: 'Michael Chen', role: 'Assistant Teacher', status: 'active', classroom: 'Infants B' },
  { id: '3', name: 'Jessica Lee', role: 'Lead Teacher', status: 'on-leave', classroom: 'Preschool A' },
];

const ENROLLMENT_DATA = [
  { name: 'Jan', enrolled: 45, waitlist: 12 },
  { name: 'Feb', enrolled: 48, waitlist: 15 },
  { name: 'Mar', enrolled: 52, waitlist: 18 },
  { name: 'Apr', enrolled: 55, waitlist: 20 },
];

const REVENUE_DATA = [
  { name: 'Mon', amount: 1200 },
  { name: 'Tue', amount: 1500 },
  { name: 'Wed', amount: 1100 },
  { name: 'Thu', amount: 1800 },
  { name: 'Fri', amount: 2100 },
];

// Generate 100 mock microservices
const MOCK_MICROSERVICES: Microservice[] = Array.from({ length: 100 }, (_, i) => ({
  id: `svc-${i + 1}`,
  name: `Service ${i + 1}`,
  domain: ['Enrollment', 'Staff', 'Billing', 'Health', 'Infra'][Math.floor(Math.random() * 5)],
  status: Math.random() > 0.95 ? 'degraded' : 'healthy',
  latency: Math.floor(Math.random() * 50) + 10,
}));

// --- Components ---

const SidebarItem = ({ 
  icon: Icon, 
  label, 
  active, 
  onClick 
}: { 
  icon: any, 
  label: string, 
  active: boolean, 
  onClick: () => void 
}) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
      active 
        ? 'bg-[#5A5A40] text-white shadow-lg shadow-[#5A5A40]/20' 
        : 'text-gray-600 hover:bg-gray-100'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium text-sm">{label}</span>
  </button>
);

const StatCard = ({ label, value, trend, icon: Icon, color }: any) => (
  <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-2xl ${color}`}>
        <Icon size={24} className="text-white" />
      </div>
      <span className={`text-xs font-bold px-2 py-1 rounded-full ${trend > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
        {trend > 0 ? '+' : ''}{trend}%
      </span>
    </div>
    <h3 className="text-gray-500 text-sm font-medium mb-1">{label}</h3>
    <p className="text-2xl font-bold text-gray-900">{value}</p>
  </div>
);

const AddChildModal = ({ isOpen, onClose, onAdd }: { isOpen: boolean, onClose: () => void, onAdd: (data: any) => void }) => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    classroom: 'Toddlers A',
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-[2rem] p-8 w-full max-w-md shadow-2xl"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold">Add New Child</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={(e) => {
          e.preventDefault();
          onAdd(formData);
        }} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
            <input 
              required
              type="text" 
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/20"
              placeholder="e.g. Liam Smith"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Age / Birthday</label>
            <input 
              required
              type="text" 
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/20"
              placeholder="e.g. 2y 4m"
              value={formData.age}
              onChange={(e) => setFormData({ ...formData, age: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Classroom</label>
            <select 
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/20"
              value={formData.classroom}
              onChange={(e) => setFormData({ ...formData, classroom: e.target.value })}
            >
              <option>Infants A</option>
              <option>Infants B</option>
              <option>Toddlers A</option>
              <option>Toddlers B</option>
              <option>Preschool A</option>
              <option>Pre-K</option>
            </select>
          </div>
          
          <div className="flex gap-3 pt-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-3 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 py-3 bg-[#5A5A40] text-white rounded-xl font-bold shadow-lg shadow-[#5A5A40]/20 hover:bg-[#4A4A30] transition-colors"
            >
              Add Child
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

function AppContent() {
  const [activeDomain, setActiveDomain] = useState<Domain>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const { user, role } = useAuth();

  // --- Real-time Data ---
  const { data: children, loading: childrenLoading } = useFirestoreCollection<Child>('children');
  const { data: staff, loading: staffLoading } = useFirestoreCollection<Staff>('staff');
  const { data: billing, loading: billingLoading } = useFirestoreCollection<any>('billing');
  const { data: schedule, loading: scheduleLoading } = useFirestoreCollection<any>('schedule');
  const { data: healthLogs, loading: healthLoading } = useFirestoreCollection<any>('health_logs');
  const { data: compliance, loading: complianceLoading } = useFirestoreCollection<any>('compliance');
  const { data: messages, loading: messagesLoading } = useFirestoreCollection<any>('messages');

  const [isAddChildModalOpen, setIsAddChildModalOpen] = useState(false);

  const handleSignOut = () => {
    auth.signOut();
  };

  const seedDatabase = async () => {
    try {
      // Seed Children
      for (const child of MOCK_CHILDREN) {
        await setDoc(doc(db, 'children', child.id), { ...child, parentUid: user?.uid });
      }
      // Seed Staff
      for (const s of MOCK_STAFF) {
        await setDoc(doc(db, 'staff', s.id), s);
      }
      // Seed Compliance
      const mockCompliance = [
        { id: '1', label: 'Staff Ratios', status: 'Compliant', color: 'bg-green-500' },
        { id: '2', label: 'Background Checks', status: '1 Pending', color: 'bg-orange-500' },
        { id: '3', label: 'Health Permits', status: 'Active', color: 'bg-green-500' },
        { id: '4', label: 'Fire Safety', status: 'Expires in 30d', color: 'bg-blue-500' },
      ];
      for (const c of mockCompliance) {
        await setDoc(doc(db, 'compliance', c.id), c);
      }
      // Seed Schedule
      const mockSchedule = [
        { id: '1', day: 'Mon', time: '09:00 AM', activity: 'Morning Circle', classroom: 'Toddlers A' },
        { id: '2', day: 'Mon', time: '10:30 AM', activity: 'Outdoor Play', classroom: 'Toddlers A' },
        { id: '3', day: 'Tue', time: '09:00 AM', activity: 'Morning Circle', classroom: 'Toddlers A' },
      ];
      for (const s of mockSchedule) {
        await setDoc(doc(db, 'schedule', s.id), s);
      }
      alert('Database seeded successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'seeding');
    }
  };

  const handleAddChild = async (childData: any) => {
    try {
      const newChildRef = doc(collection(db, 'children'));
      await setDoc(newChildRef, {
        ...childData,
        id: newChildRef.id,
        parentUid: user?.uid,
        lastActivity: 'Just Enrolled',
        status: 'enrolled'
      });
      setIsAddChildModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'children');
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-[#1a1a1a] font-sans selection:bg-[#5A5A40] selection:text-white">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-white border-bottom border-gray-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#5A5A40] rounded-lg flex items-center justify-center">
            <Baby className="text-white" size={18} />
          </div>
          <span className="font-bold text-lg">LittleSteps</span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </div>

      <div className="flex h-screen overflow-hidden">
        {/* Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              className="fixed lg:relative z-50 w-72 h-full bg-white border-r border-gray-100 p-6 flex flex-col gap-8"
            >
              <div className="flex items-center gap-3 px-2">
                <div className="w-10 h-10 bg-[#5A5A40] rounded-xl flex items-center justify-center shadow-lg shadow-[#5A5A40]/20">
                  <Baby className="text-white" size={24} />
                </div>
                <div>
                  <h1 className="font-bold text-xl leading-tight">LittleSteps</h1>
                  <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">Management System</p>
                </div>
              </div>

              <nav className="flex-1 flex flex-col gap-1 overflow-y-auto pr-2 custom-scrollbar">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em] px-4 mb-2">Main</p>
                <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeDomain === 'dashboard'} onClick={() => setActiveDomain('dashboard')} />
                <SidebarItem icon={Baby} label="Enrollment" active={activeDomain === 'enrollment'} onClick={() => setActiveDomain('enrollment')} />
                <SidebarItem icon={Users} label="Staff Management" active={activeDomain === 'staff'} onClick={() => setActiveDomain('staff')} />
                <SidebarItem icon={CreditCard} label="Billing & Payments" active={activeDomain === 'billing'} onClick={() => setActiveDomain('billing')} />
                
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em] px-4 mt-6 mb-2">Operations</p>
                <SidebarItem icon={Calendar} label="Scheduling" active={activeDomain === 'scheduling'} onClick={() => setActiveDomain('scheduling')} />
                <SidebarItem icon={HeartPulse} label="Health & Safety" active={activeDomain === 'health'} onClick={() => setActiveDomain('health')} />
                <SidebarItem icon={ShieldCheck} label="Compliance" active={activeDomain === 'compliance'} onClick={() => setActiveDomain('compliance')} />
                <SidebarItem icon={MessageSquare} label="Parent Portal" active={activeDomain === 'parent_portal'} onClick={() => setActiveDomain('parent_portal')} />
                
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em] px-4 mt-6 mb-2">System</p>
                <SidebarItem icon={Activity} label="Microservices" active={activeDomain === 'infrastructure'} onClick={() => setActiveDomain('infrastructure')} />
                <SidebarItem icon={Settings} label="Settings" active={activeDomain === 'operations'} onClick={() => setActiveDomain('operations')} />
              </nav>

              <div className="bg-gray-50 p-4 rounded-2xl">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gray-200 border-2 border-white overflow-hidden">
                    <img src="https://picsum.photos/seed/admin/100/100" alt="Admin" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">{user?.displayName || 'Admin User'}</p>
                    <p className="text-xs text-gray-500 capitalize">{role || 'Director'}</p>
                  </div>
                </div>
                <button 
                  onClick={handleSignOut}
                  className="w-full py-2 text-xs font-bold text-red-500 hover:bg-red-50 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <LogOut size={14} />
                  Sign Out
                </button>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-10 custom-scrollbar">
          {/* Top Bar */}
          <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-10">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 capitalize">{activeDomain}</h2>
              <p className="text-gray-500">Welcome back, here's what's happening today.</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Search anything..." 
                  className="pl-10 pr-4 py-2.5 bg-white border border-gray-100 rounded-2xl w-full lg:w-64 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/20 transition-all"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button className="p-2.5 bg-white border border-gray-100 rounded-2xl text-gray-600 hover:bg-gray-50 transition-all relative">
                <Bell size={20} />
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
              </button>
              <button className="flex items-center gap-2 px-4 py-2.5 bg-[#5A5A40] text-white rounded-2xl font-bold hover:bg-[#4A4A30] transition-all shadow-lg shadow-[#5A5A40]/20">
                <Plus size={18} />
                <span>New Action</span>
              </button>
            </div>
          </header>

          {/* Domain Views */}
          <AnimatePresence mode="wait">
            {activeDomain === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <StatCard label="Total Children" value={childrenLoading ? '...' : children.length} trend={12} icon={Baby} color="bg-blue-500" />
                  <StatCard label="Staff Active" value={staffLoading ? '...' : `${staff.filter(s => s.status === 'active').length}/${staff.length}`} trend={-2} icon={Users} color="bg-orange-500" />
                  <StatCard label="Revenue (MTD)" value={billingLoading ? '...' : `$${billing.filter(b => b.status === 'paid').reduce((acc, b) => acc + parseFloat(b.amount.replace('$', '').replace(',', '')), 0).toLocaleString()}`} trend={8} icon={CreditCard} color="bg-green-500" />
                  <StatCard label="System Health" value="99.9%" trend={0.1} icon={Activity} color="bg-purple-500" />
                </div>

                {/* Charts Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-8">
                      <h3 className="font-bold text-lg">Enrollment Growth</h3>
                      <select className="text-sm bg-gray-50 border-none rounded-lg px-2 py-1 focus:ring-0">
                        <option>Last 6 Months</option>
                        <option>Last Year</option>
                      </select>
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={ENROLLMENT_DATA}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                            cursor={{ fill: '#f9fafb' }}
                          />
                          <Bar dataKey="enrolled" fill="#5A5A40" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="waitlist" fill="#d1d5db" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-8">
                      <h3 className="font-bold text-lg">Weekly Revenue</h3>
                      <div className="flex gap-2">
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <div className="w-2 h-2 rounded-full bg-[#5A5A40]"></div>
                          <span>Tuition</span>
                        </div>
                      </div>
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={REVENUE_DATA}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                          />
                          <Line type="monotone" dataKey="amount" stroke="#5A5A40" strokeWidth={3} dot={{ r: 4, fill: '#5A5A40' }} activeDot={{ r: 6 }} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Recent Activity & Staff */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden">
                    <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                      <h3 className="font-bold text-lg">Recent Child Activity</h3>
                      <button className="text-sm font-bold text-[#5A5A40] hover:underline">View All</button>
                    </div>
                    <div className="divide-y divide-gray-50">
                      {(children.length > 0 ? children : MOCK_CHILDREN).map((child) => (
                        <div key={child.id} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-2xl bg-gray-100 overflow-hidden">
                              <img src={`https://picsum.photos/seed/${child.id}/100/100`} alt={child.name} referrerPolicy="no-referrer" />
                            </div>
                            <div>
                              <p className="font-bold text-gray-900">{child.name}</p>
                              <p className="text-xs text-gray-500">{child.classroom} • {child.age}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                            <div className="text-right">
                              <p className="text-sm font-medium text-gray-700">{child.lastActivity}</p>
                              <p className="text-[10px] text-gray-400 uppercase font-bold">Current Status</p>
                            </div>
                            <div className={`w-2 h-2 rounded-full ${child.status === 'enrolled' ? 'bg-green-500' : 'bg-orange-500'}`}></div>
                            <ChevronRight size={18} className="text-gray-300" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden">
                    <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                      <h3 className="font-bold text-lg">Staff on Duty</h3>
                      <button className="text-sm font-bold text-[#5A5A40] hover:underline">Manage</button>
                    </div>
                    <div className="p-6 space-y-6">
                      {(staff.length > 0 ? staff : MOCK_STAFF).map((staff) => (
                        <div key={staff.id} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gray-100 overflow-hidden">
                              <img src={`https://picsum.photos/seed/staff-${staff.id}/100/100`} alt={staff.name} referrerPolicy="no-referrer" />
                            </div>
                            <div>
                              <p className="text-sm font-bold">{staff.name}</p>
                              <p className="text-[10px] text-gray-500 uppercase font-bold">{staff.role}</p>
                            </div>
                          </div>
                          <div className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase ${
                            staff.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                          }`}>
                            {staff.status}
                          </div>
                        </div>
                      ))}
                      <div className="pt-4 border-top border-gray-50">
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-500">Staff to Child Ratio</span>
                          <span className="font-bold text-green-600">Optimal (1:4)</span>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="w-[85%] h-full bg-green-500"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'infrastructure' && (
              <motion.div
                key="infra"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-8"
              >
                <div className="bg-[#151619] text-white p-8 rounded-[2.5rem] shadow-2xl">
                  <div className="flex items-center justify-between mb-10">
                    <div>
                      <h3 className="text-2xl font-bold mb-2">Microservice Mesh Dashboard</h3>
                      <p className="text-gray-400 text-sm">Monitoring 100 active services across 10 domains</p>
                    </div>
                    <div className="flex gap-4">
                      <div className="text-center px-4 py-2 bg-white/5 rounded-2xl">
                        <p className="text-xs text-gray-500 uppercase font-bold">Healthy</p>
                        <p className="text-xl font-bold text-green-400">96</p>
                      </div>
                      <div className="text-center px-4 py-2 bg-white/5 rounded-2xl">
                        <p className="text-xs text-gray-500 uppercase font-bold">Degraded</p>
                        <p className="text-xl font-bold text-orange-400">4</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-5 md:grid-cols-10 lg:grid-cols-20 gap-2">
                    {MOCK_MICROSERVICES.map((svc) => (
                      <div 
                        key={svc.id}
                        title={`${svc.name} (${svc.domain}) - ${svc.latency}ms`}
                        className={`aspect-square rounded-md transition-all duration-300 hover:scale-125 cursor-help ${
                          svc.status === 'healthy' ? 'bg-green-500/40 border border-green-500/50' : 'bg-orange-500/40 border border-orange-500/50 animate-pulse'
                        }`}
                      ></div>
                    ))}
                  </div>

                  <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Network Latency</h4>
                      <div className="flex items-end gap-1 h-20">
                        {Array.from({ length: 20 }).map((_, i) => (
                          <div key={i} className="flex-1 bg-blue-400/30 rounded-t-sm" style={{ height: `${Math.random() * 100}%` }}></div>
                        ))}
                      </div>
                      <div className="flex justify-between mt-2 text-[10px] text-gray-500">
                        <span>0ms</span>
                        <span>Avg: 24ms</span>
                        <span>100ms</span>
                      </div>
                    </div>
                    
                    <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Event Bus Throughput</h4>
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <p className="text-2xl font-bold">1.2k <span className="text-xs font-normal text-gray-500">msg/s</span></p>
                          <div className="w-full h-1.5 bg-white/10 rounded-full mt-2 overflow-hidden">
                            <motion.div 
                              animate={{ x: [0, 100, 0] }}
                              transition={{ duration: 2, repeat: Infinity }}
                              className="w-1/3 h-full bg-purple-500"
                            ></motion.div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Error Rate</h4>
                      <div className="flex items-center justify-between">
                        <p className="text-3xl font-bold text-green-400">0.02%</p>
                        <ShieldCheck className="text-green-400" size={32} />
                      </div>
                      <p className="text-[10px] text-gray-500 mt-2">Well below 1% threshold</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                    <h3 className="font-bold text-lg mb-6">Active Domain Clusters</h3>
                    <div className="space-y-4">
                      {['Enrollment', 'Billing', 'Staff', 'Health', 'Parent Portal'].map((domain) => (
                        <div key={domain} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="font-bold text-sm">{domain} Domain</span>
                          </div>
                          <span className="text-xs text-gray-500">12 Services • 3 Replicas</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                    <h3 className="font-bold text-lg mb-6">Recent System Events</h3>
                    <div className="space-y-4">
                      {[
                        { time: '2m ago', event: 'Billing Service scaled to 4 replicas', type: 'info' },
                        { time: '15m ago', event: 'Database backup completed successfully', type: 'success' },
                        { time: '1h ago', event: 'High latency detected in Notification Service', type: 'warning' },
                        { time: '3h ago', event: 'New deployment: Parent Portal v2.4.1', type: 'info' },
                      ].map((log, i) => (
                        <div key={i} className="flex gap-4">
                          <span className="text-xs text-gray-400 font-mono w-16">{log.time}</span>
                          <p className="text-sm text-gray-700">{log.event}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'enrollment' && (
              <motion.div
                key="enrollment"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Child Enrollment</h3>
                    <div className="flex gap-3">
                      <button className="px-4 py-2 bg-white border border-gray-100 rounded-xl text-sm font-bold hover:bg-gray-50">Export List</button>
                      <button 
                        onClick={() => setIsAddChildModalOpen(true)}
                        className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20"
                      >
                        Add New Child
                      </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  <div className="bg-white p-6 rounded-3xl border border-gray-100 text-center">
                    <p className="text-3xl font-bold text-blue-600">{childrenLoading ? '...' : children.filter(c => c.status === 'enrolled').length}</p>
                    <p className="text-xs text-gray-500 font-bold uppercase mt-1">Enrolled</p>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-gray-100 text-center">
                    <p className="text-3xl font-bold text-orange-600">{childrenLoading ? '...' : children.filter(c => c.status === 'waitlist').length}</p>
                    <p className="text-xs text-gray-500 font-bold uppercase mt-1">Waitlist</p>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-gray-100 text-center">
                    <p className="text-3xl font-bold text-green-600">{childrenLoading ? '...' : children.filter(c => c.status === 'enrolled').length}</p>
                    <p className="text-xs text-gray-500 font-bold uppercase mt-1">New This Month</p>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-gray-100 text-center">
                    <p className="text-3xl font-bold text-gray-600">{childrenLoading ? '...' : Math.round((children.filter(c => c.status === 'enrolled').length / 100) * 100)}%</p>
                    <p className="text-xs text-gray-500 font-bold uppercase mt-1">Capacity</p>
                  </div>
                </div>

                <div className="bg-white rounded-[2rem] border border-gray-100 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-100">
                          <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Child</th>
                          <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Age</th>
                          <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Classroom</th>
                          <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Parent/Guardian</th>
                          <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Status</th>
                          <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {(children.length > 0 ? children : MOCK_CHILDREN).map((child) => (
                          <tr key={child.id} className="hover:bg-gray-50/50 transition-colors">
                            <td className="px-8 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-gray-100 overflow-hidden">
                                  <img src={`https://picsum.photos/seed/${child.id}/100/100`} alt={child.name} referrerPolicy="no-referrer" />
                                </div>
                                <span className="font-bold">{child.name}</span>
                              </div>
                            </td>
                            <td className="px-8 py-4 text-sm text-gray-600">{child.age}</td>
                            <td className="px-8 py-4 text-sm text-gray-600">{child.classroom}</td>
                            <td className="px-8 py-4 text-sm text-gray-600">John Smith</td>
                            <td className="px-8 py-4">
                              <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                                child.status === 'enrolled' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                              }`}>
                                {child.status}
                              </span>
                            </td>
                            <td className="px-8 py-4">
                              <button className="p-2 text-gray-400 hover:text-[#5A5A40] transition-colors">
                                <Settings size={18} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'staff' && (
              <motion.div
                key="staff"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Staff Management</h3>
                  <button className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20">Add Staff Member</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {(staff.length > 0 ? staff : MOCK_STAFF).map((staff) => (
                    <div key={staff.id} className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all group">
                      <div className="flex justify-between items-start mb-6">
                        <div className="w-20 h-20 rounded-3xl bg-gray-100 overflow-hidden border-4 border-white shadow-sm">
                          <img src={`https://picsum.photos/seed/staff-${staff.id}/200/200`} alt={staff.name} referrerPolicy="no-referrer" />
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                          staff.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                        }`}>
                          {staff.status}
                        </div>
                      </div>
                      <h4 className="text-xl font-bold mb-1">{staff.name}</h4>
                      <p className="text-sm text-gray-500 font-medium mb-4">{staff.role}</p>
                      
                      <div className="space-y-3 pt-4 border-t border-gray-50">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <LayoutDashboard size={16} className="text-gray-400" />
                          <span>Classroom: {staff.classroom}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock size={16} className="text-gray-400" />
                          <span>Shift: 08:00 AM - 04:00 PM</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <ShieldCheck size={16} className="text-gray-400" />
                          <span>Certifications: CPR, First Aid</span>
                        </div>
                      </div>

                      <div className="mt-8 flex gap-2">
                        <button className="flex-1 py-2 bg-gray-50 text-gray-600 rounded-xl text-xs font-bold hover:bg-gray-100 transition-colors">View Profile</button>
                        <button className="flex-1 py-2 bg-[#5A5A40]/10 text-[#5A5A40] rounded-xl text-xs font-bold hover:bg-[#5A5A40]/20 transition-colors">Schedule</button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeDomain === 'billing' && (
              <motion.div
                key="billing"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Billing & Invoices</h3>
                  <button className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20">Generate Invoices</button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-3xl border border-gray-100">
                    <p className="text-xs text-gray-500 font-bold uppercase mb-2">Total Outstanding</p>
                    <p className="text-3xl font-bold text-red-600">$12,450</p>
                    <div className="mt-4 flex items-center gap-2 text-xs text-red-500 font-bold">
                      <AlertCircle size={14} />
                      <span>14 Overdue Invoices</span>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-gray-100">
                    <p className="text-xs text-gray-500 font-bold uppercase mb-2">Collected (MTD)</p>
                    <p className="text-3xl font-bold text-green-600">$42,500</p>
                    <div className="mt-4 flex items-center gap-2 text-xs text-green-500 font-bold">
                      <CheckCircle2 size={14} />
                      <span>92% Collection Rate</span>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-gray-100">
                    <p className="text-xs text-gray-500 font-bold uppercase mb-2">Pending Subsidies</p>
                    <p className="text-3xl font-bold text-blue-600">$5,200</p>
                    <div className="mt-4 flex items-center gap-2 text-xs text-blue-500 font-bold">
                      <Clock size={14} />
                      <span>Awaiting State Approval</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-[2rem] border border-gray-100 overflow-hidden">
                  <div className="p-8 border-b border-gray-50">
                    <h4 className="font-bold">Recent Transactions</h4>
                  </div>
                  <div className="divide-y divide-gray-50">
                    {[
                      { id: 'INV-001', child: 'Liam Smith', amount: '$1,200', date: 'Mar 25, 2026', status: 'paid' },
                      { id: 'INV-002', child: 'Olivia Brown', amount: '$1,200', date: 'Mar 24, 2026', status: 'overdue' },
                      { id: 'INV-003', child: 'Noah Davis', amount: '$1,350', date: 'Mar 22, 2026', status: 'paid' },
                      { id: 'INV-004', child: 'Emma Wilson', amount: '$1,200', date: 'Mar 20, 2026', status: 'pending' },
                    ].map((inv) => (
                      <div key={inv.id} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center text-gray-400">
                            <CreditCard size={20} />
                          </div>
                          <div>
                            <p className="font-bold text-gray-900">{inv.id}</p>
                            <p className="text-xs text-gray-500">{inv.child}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-8">
                          <div className="text-right">
                            <p className="font-bold">{inv.amount}</p>
                            <p className="text-xs text-gray-400">{inv.date}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                            inv.status === 'paid' ? 'bg-green-100 text-green-700' : 
                            inv.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            {inv.status}
                          </span>
                          <button className="text-gray-400 hover:text-[#5A5A40]">
                            <ChevronRight size={20} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'health' && (
              <motion.div
                key="health"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Health & Safety Logs</h3>
                  <button className="px-4 py-2 bg-red-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-red-500/20">Report Incident</button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                    <h4 className="font-bold mb-6 flex items-center gap-2">
                      <HeartPulse className="text-red-500" size={20} />
                      Daily Health Checks
                    </h4>
                    <div className="space-y-4">
                      {MOCK_CHILDREN.slice(0, 4).map((child) => (
                        <div key={child.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-gray-200 overflow-hidden">
                              <img src={`https://picsum.photos/seed/${child.id}/100/100`} alt={child.name} referrerPolicy="no-referrer" />
                            </div>
                            <div>
                              <p className="text-sm font-bold">{child.name}</p>
                              <p className="text-[10px] text-gray-500 uppercase font-bold">Temp: 98.6°F</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button className="p-2 bg-green-100 text-green-700 rounded-lg"><CheckCircle2 size={16} /></button>
                            <button className="p-2 bg-gray-100 text-gray-400 rounded-lg"><AlertCircle size={16} /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                    <h4 className="font-bold mb-6 flex items-center gap-2">
                      <ShieldCheck className="text-blue-500" size={20} />
                      Safety Inspections
                    </h4>
                    <div className="space-y-4">
                      {[
                        { area: 'Playground Equipment', status: 'Passed', date: 'Today, 08:00 AM' },
                        { area: 'Kitchen Sanitation', status: 'Passed', date: 'Today, 07:30 AM' },
                        { area: 'Fire Extinguishers', status: 'Due in 3 days', date: 'Last check: Feb 28' },
                        { area: 'First Aid Kits', status: 'Passed', date: 'Yesterday, 04:00 PM' },
                      ].map((check, i) => (
                        <div key={i} className="p-4 border border-gray-50 rounded-2xl">
                          <div className="flex justify-between items-start mb-1">
                            <p className="font-bold text-sm">{check.area}</p>
                            <span className={`text-[10px] font-bold uppercase ${check.status === 'Passed' ? 'text-green-600' : 'text-orange-600'}`}>
                              {check.status}
                            </span>
                          </div>
                          <p className="text-xs text-gray-400">{check.date}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'scheduling' && (
              <motion.div
                key="scheduling"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Classroom Scheduling</h3>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-bold">Week View</button>
                    <button className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20">New Event</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-7 gap-4">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
                    <div key={day} className={`bg-white rounded-2xl border border-gray-100 p-4 min-h-[400px] ${i > 4 ? 'bg-gray-50/50' : ''}`}>
                      <p className="text-xs font-bold text-gray-400 uppercase mb-4 text-center">{day}</p>
                      <div className="space-y-3">
                        {i < 5 && (
                          <>
                            <div className="p-2 bg-blue-50 border-l-4 border-blue-500 rounded-lg">
                              <p className="text-[10px] font-bold text-blue-700">09:00 AM</p>
                              <p className="text-xs font-bold">Morning Circle</p>
                            </div>
                            <div className="p-2 bg-green-50 border-l-4 border-green-500 rounded-lg">
                              <p className="text-[10px] font-bold text-green-700">10:30 AM</p>
                              <p className="text-xs font-bold">Outdoor Play</p>
                            </div>
                            {i % 2 === 0 && (
                              <div className="p-2 bg-orange-50 border-l-4 border-orange-500 rounded-lg">
                                <p className="text-[10px] font-bold text-orange-700">01:00 PM</p>
                                <p className="text-xs font-bold">Nap Time</p>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeDomain === 'compliance' && (
              <motion.div
                key="compliance"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Compliance & Licensing</h3>
                  <button className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20">Run Audit</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Staff Ratios', status: 'Compliant', color: 'bg-green-500' },
                    { label: 'Background Checks', status: '1 Pending', color: 'bg-orange-500' },
                    { label: 'Health Permits', status: 'Active', color: 'bg-green-500' },
                    { label: 'Fire Safety', status: 'Expires in 30d', color: 'bg-blue-500' },
                  ].map((item, i) => (
                    <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100">
                      <div className={`w-2 h-2 rounded-full ${item.color} mb-3`}></div>
                      <p className="text-xs text-gray-400 font-bold uppercase mb-1">{item.label}</p>
                      <p className="text-lg font-bold">{item.status}</p>
                    </div>
                  ))}
                </div>

                <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                  <h4 className="font-bold mb-6">Upcoming Deadlines</h4>
                  <div className="space-y-4">
                    {[
                      { title: 'State License Renewal', date: 'Apr 15, 2026', priority: 'High' },
                      { title: 'Staff Training: Child Safety', date: 'Apr 20, 2026', priority: 'Medium' },
                      { title: 'Annual Health Inspection', date: 'May 02, 2026', priority: 'Medium' },
                    ].map((task, i) => (
                      <div key={i} className="flex items-center justify-between p-4 border border-gray-50 rounded-2xl hover:bg-gray-50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className={`w-2 h-10 rounded-full ${task.priority === 'High' ? 'bg-red-500' : 'bg-blue-500'}`}></div>
                          <div>
                            <p className="font-bold text-sm">{task.title}</p>
                            <p className="text-xs text-gray-400">{task.date}</p>
                          </div>
                        </div>
                        <button className="text-xs font-bold text-[#5A5A40] hover:underline">View Details</button>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'parent_portal' && (
              <motion.div
                key="parent_portal"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold">Parent Communication</h3>
                  <button className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20">Broadcast Message</button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                      <h4 className="font-bold mb-6">Recent Activity Feed</h4>
                      <div className="space-y-6">
                        {[
                          { parent: 'Sarah Johnson', child: 'Liam', message: 'Liam had a great nap today! He slept for 1.5 hours.', time: '10 mins ago', type: 'update' },
                          { parent: 'Michael Brown', child: 'Olivia', message: 'Olivia finished her lunch completely.', time: '45 mins ago', type: 'update' },
                          { parent: 'Emily Davis', child: 'Noah', message: 'Noah participated well in the music session.', time: '2 hours ago', type: 'update' },
                        ].map((post, i) => (
                          <div key={i} className="flex gap-4">
                            <div className="w-10 h-10 rounded-full bg-gray-100 flex-shrink-0">
                              <img src={`https://picsum.photos/seed/parent-${i}/100/100`} alt={post.parent} className="rounded-full" referrerPolicy="no-referrer" />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start mb-1">
                                <p className="text-sm font-bold">{post.parent} <span className="text-gray-400 font-normal">for</span> {post.child}</p>
                                <span className="text-[10px] text-gray-400">{post.time}</span>
                              </div>
                              <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-2xl rounded-tl-none">{post.message}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-white p-8 rounded-[2rem] border border-gray-100">
                      <h4 className="font-bold mb-6">Unread Messages</h4>
                      <div className="space-y-4">
                        {[
                          { name: 'John Smith', subject: 'Early pickup today', time: '5m' },
                          { name: 'Alice Wilson', subject: 'Allergy update', time: '1h' },
                        ].map((msg, i) => (
                          <div key={i} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl cursor-pointer transition-colors">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-[#5A5A40]/10 flex items-center justify-center text-[#5A5A40] font-bold text-xs">
                                {msg.name[0]}
                              </div>
                              <div>
                                <p className="text-xs font-bold">{msg.name}</p>
                                <p className="text-[10px] text-gray-500 truncate w-32">{msg.subject}</p>
                              </div>
                            </div>
                            <span className="text-[10px] text-gray-400">{msg.time}</span>
                          </div>
                        ))}
                      </div>
                      <button className="w-full mt-6 py-2 text-xs font-bold text-[#5A5A40] hover:bg-[#5A5A40]/5 rounded-lg transition-colors">View All Messages</button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeDomain === 'operations' && (
              <motion.div
                key="settings"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="bg-white rounded-[2rem] border border-gray-100 overflow-hidden">
                  <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                    <h3 className="text-xl font-bold">System Settings</h3>
                    <button 
                      onClick={seedDatabase}
                      className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#5A5A40]/20"
                    >
                      Seed Database
                    </button>
                  </div>
                  <div className="p-8 space-y-8">
                    <section>
                      <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Facility Information</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-gray-600">Facility Name</label>
                          <input type="text" defaultValue="LittleSteps DayCare" className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-[#5A5A40]/20" />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-gray-600">License Number</label>
                          <input type="text" defaultValue="LIC-2026-99182" className="w-full px-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-[#5A5A40]/20" />
                        </div>
                      </div>
                    </section>

                    <section>
                      <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Notifications</h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                          <div>
                            <p className="font-bold text-sm">Parent Push Notifications</p>
                            <p className="text-xs text-gray-500">Send real-time activity updates to parents</p>
                          </div>
                          <div className="w-12 h-6 bg-[#5A5A40] rounded-full relative cursor-pointer">
                            <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                          <div>
                            <p className="font-bold text-sm">Staff Shift Reminders</p>
                            <p className="text-xs text-gray-500">Automated SMS 1 hour before shift starts</p>
                          </div>
                          <div className="w-12 h-6 bg-gray-200 rounded-full relative cursor-pointer">
                            <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      <AddChildModal 
        isOpen={isAddChildModalOpen} 
        onClose={() => setIsAddChildModalOpen(false)} 
        onAdd={handleAddChild} 
      />

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e5e7eb;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #d1d5db;
        }
      `}</style>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <FirebaseProvider>
        <AuthGuard>
          <AppContent />
        </AuthGuard>
      </FirebaseProvider>
    </ErrorBoundary>
  );
}
