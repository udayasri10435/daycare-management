import React from 'react';
import { useAuth } from './FirebaseProvider';
import { auth, googleProvider, signInWithPopup, db, doc, setDoc, OperationType, handleFirestoreError } from '../firebase';
import { Baby, LogIn, Loader2 } from 'lucide-react';

export const AuthGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      
      // Ensure user profile exists in Firestore
      const userDocRef = doc(db, 'users', user.uid);
      try {
        await setDoc(userDocRef, {
          uid: user.uid,
          name: user.displayName || 'Anonymous',
          email: user.email || '',
          role: user.email === 'udayaprinter.gamini@gmail.com' ? 'admin' : 'parent'
        }, { merge: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
      }
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5f5f0] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-[#5A5A40] rounded-2xl flex items-center justify-center mx-auto shadow-xl shadow-[#5A5A40]/20 animate-pulse">
            <Baby className="text-white" size={32} />
          </div>
          <p className="text-[#5A5A40] font-bold text-lg flex items-center gap-2">
            <Loader2 className="animate-spin" size={20} />
            Initializing LittleSteps...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#f5f5f0] flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-2xl max-w-md w-full text-center space-y-8">
          <div className="w-20 h-20 bg-[#5A5A40] rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-[#5A5A40]/20">
            <Baby className="text-white" size={40} />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-bold text-gray-900">Welcome Back</h2>
            <p className="text-gray-500 text-sm leading-relaxed">
              Access the LittleSteps Management System to manage your daycare operations efficiently.
            </p>
          </div>
          <button
            onClick={handleLogin}
            className="w-full py-4 bg-[#5A5A40] text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-[#4a4a34] transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-[#5A5A40]/20"
          >
            <LogIn size={20} />
            Sign in with Google
          </button>
          <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">
            Secure Enterprise Authentication
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
